<?php

    include("mail.php");
    if(isset($_POST['send_mail']))
    {
        $to=$_POST['email'];
        $subject=$_POST['subject'];
        $msg=$_POST['message'];
        $res=send_mail($to,$subject,$msg);
    }
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
</head>
<body>
    <form method="post">
        <div class="form-group">
            <label for="">To</label>
            <input type="email" name="email" id="">
        </div>
        <div class="form-group">
            <label for="">Subject</label>
            <input type="text" name="subject" id="">
        </div>
        <div class="form-group">
            <label for="">Message</label>
            <textarea name="message" id="" cols="30" rows="10"></textarea>
        </div>
        <input type="submit" value="Send Email" name="send_mail">
    </form>
    <p><?php if(isset($res)) echo $res; ?></p>
</body>
</html>